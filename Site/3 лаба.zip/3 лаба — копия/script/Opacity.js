setTimeout(function(){
	document.body.classList.add('body_visible');
}, 200);